import React, { useState, useEffect } from 'react';
import { StyleSheet, SafeAreaView } from 'react-native';
import { StatusBar } from 'expo-status-bar';

import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import home from './home';
import result from './resultado';
import qrcode from './qrcode';


const Stack = createNativeStackNavigator();

export default function App() {
 

  return (
    <NavigationContainer>
       <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="Home" component={home} />
       <Stack.Screen name="Resultado" component={result} />
        <Stack.Screen name="Qrcode" component={qrcode} />

    </Stack.Navigator>
    </NavigationContainer>
  );
}
