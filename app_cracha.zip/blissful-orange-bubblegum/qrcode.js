import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
} from 'react-native';

import QRCode from 'react-native-qrcode-svg';

export default function Qrcode({ route, navigation }) {

  const { rm } = route.params;

  return (
    <View style={styles.container}>

      <View style={styles.card}>

        <Text style={styles.titulo}>
          QR Code
        </Text>

        <Text style={styles.label}>
          RM
        </Text>

        <View style={styles.input}>
          <Text style={styles.texto}>
            {rm}
          </Text>
        </View>

        <View style={styles.areaQR}>

          <QRCode
            value={String(rm)}
            size={250}
          />

        </View>

      </View>

      <TouchableOpacity
        style={styles.btnVoltar}
        onPress={() => navigation.goBack()}
      >
        <Text style={styles.txtbtn}>
          Voltar
        </Text>
      </TouchableOpacity>

    </View>
  );
}

const styles = StyleSheet.create({

  container: {
    flex: 1,
    paddingTop: 70,
    alignItems: 'center',
    backgroundColor: '#000',
  },

  card: {
    backgroundColor: '#1d1d1d',
    width: '90%',
    height: 600,
    borderWidth: 1,
    borderColor: '#007bff',
    borderRadius: 12,
  },

  titulo: {
    fontSize: 30,
    fontWeight: 'bold',
    color: '#fff',
    alignSelf: 'center',
    marginTop: 10,
    borderColor: '#00ff88',
    borderRadius: 12,
    borderBottomWidth: 6,
  },

  label: {
    marginLeft: 20,
    color: '#014bff',
    fontSize: 15,
    fontWeight: 'bold',
    letterSpacing: 1,
    marginBottom: 4,
    marginTop: 20,
  },

  input: {
    marginTop: 4,
    borderBottomWidth: 2,
    borderBottomColor: '#292d35',
    marginLeft: 20,
    marginRight: 20,
    marginBottom: 10,
  },

  texto: {
    fontSize: 25,
    fontWeight: 'bold',
    marginLeft: 10,
    paddingLeft: 10,
    color: '#fff',
    paddingBottom: 8,
  },

  areaQR: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },

  btnVoltar: {
    marginTop: 30,
    padding: 8,
    borderRadius: 10,
    width: 100,
    backgroundColor: '#fff',
  },

  txtbtn: {
    textAlign: 'center',
    fontSize: 20,
  },

});