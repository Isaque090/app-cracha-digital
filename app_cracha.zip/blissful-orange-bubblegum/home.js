import React, { useState } from 'react';
import {
  View,
  Text,
  Button,
  Image,
  StyleSheet,
  Alert,
  TextInput,TouchableOpacity
} from 'react-native';
import { Picker } from '@react-native-picker/picker';
import * as ImagePicker from 'expo-image-picker';
import axios from 'axios';

export default function Home({ navigation }) {
  const [imagem, setImagem] = useState(null);
    const [nome, setnome] = useState('');
 const [rm, setrm] = useState('');
 const [dtnascimento, setdtnascimento] = useState('');
  const [curso, setcurso] = useState('');


              

  const escolherImagem = async () => {
    Alert.alert('Adicionar foto', 'Escolha uma opção',
    [
      {
        text: 'Tirar foto',
        onPress: async () => {
          const permissao =
            await ImagePicker.requestCameraPermissionsAsync();

          if (!permissao.granted) {
            Alert.alert(
              'Permissão negada',
              'Permita o acesso à câmera.'
            );
            return;
          }

          const resultado =
            await ImagePicker.launchCameraAsync({
              allowsEditing: true,
              quality: 1,
            });

          if (!resultado.canceled) {
            setImagem(resultado.assets[0].uri);
          }
        },
      },
      {
        text: 'Escolher da galeria',
        onPress: async () => {
          const permissao =
            await ImagePicker.requestMediaLibraryPermissionsAsync();

          if (!permissao.granted) {
            Alert.alert(
              'Permissão negada',
              'Permita o acesso às fotos.'
            );
            return;
          }

          const resultado =
            await ImagePicker.launchImageLibraryAsync({
              mediaTypes: ['images'],
              allowsEditing: true,
              quality: 1,
            });

          if (!resultado.canceled) {
            setImagem(resultado.assets[0].uri);
          }
        },
      },
    
    ]
  );
};

  return (
    <View style={styles.container}>
      <Text style={styles.titulo}>Selecionar uma imagem</Text>

   <TouchableOpacity
  style={styles.imagemcard}
  onPress={escolherImagem}
>
  {imagem ? (
   <Image source={{ uri: imagem }} style={styles.imagem} />
  ) : (
    <>
      <Text style={styles.mais}>+</Text>
      <Text style={styles.textoCard}>
        Adicionar foto
      </Text>
    </>
  )}
</TouchableOpacity>
      <TextInput
        style={styles.input}
        placeholder="Nome"
         value={nome}
        onChangeText={setnome}
        placeholderTextColor="#999"
      />
        <TextInput
        style={styles.input}
        placeholder="RM"
        placeholderTextColor="#999"
        value={rm}
        onChangeText={setrm}
        keyboardType="numeric"
      />
       <TextInput
        style={styles.input}
        placeholder="Data de nascimento"
         value={dtnascimento}
        onChangeText={setdtnascimento}
        placeholderTextColor="#999"
      />
      <View style={styles.select}>
  <Picker
    selectedValue={curso}
    onValueChange={(itemValue) => setcurso(itemValue)}
  >
    <Picker.Item label="Selecione o curso" value="" />
    <Picker.Item label="Desenvolvimento de Sistemas" value="Desenvolvimento de Sistemas" />
    <Picker.Item label="Administração" value="Administração" />
    <Picker.Item label="Informatica Para Internet" value="Informatica Para Internet" />
  
  </Picker>
</View>
      
      <Button title="Enviar" onPress={enviar} />
     
    </View>
  );

function enviar(){
 if (nome== ''|| rm==''|| dtnascimento==''||imagem==null||curso=='') {
      Alert.alert('Atenção','Preencha todos os campos e selecione uma imagem.');
      return;
    }
      navigation.navigate('Resultado', {
                  nome: nome,
                  curso: curso,
                  rm: rm,
                  imagem: imagem,
                  dtnascimento: dtnascimento,
                });
   

}
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
    backgroundColor:'#000'
  },

select: {
  width: '90%',
  height: 50,
  marginTop: 15,
  marginBottom: 15,
  borderWidth: 1,
  borderColor: '#007bff',
  borderRadius: 12,
  backgroundColor: '#fff',
  justifyContent: 'center',
},
  titulo: {
    fontSize: 24,
    fontWeight: 'bold',
    color:'#fff',
    marginBottom: 20,
  },

  imagem: {
    width: 150,
    height: 150,
    
    borderRadius: 10,
  },
  
  imagemcard: {
     backgroundColor:'#1f1f1f',
     width:150,
     height:150,
     borderRadius:10,
     borderWidth: 2,
     borderColor: '#007bff',
     borderStyle: 'dashed',
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'hidden',
  },
  mais:{
    fontSize:20,
    color:'#fff',
  },
  textoCard:{
     color:'#fff',
     fontSize:20,
  },
  input: {
    width: '90%',
    height: 50,
    marginTop:30,
    borderWidth: 1,
    borderColor: '#007bff',
    borderRadius: 12,
    paddingHorizontal: 15,
    fontSize: 16,
    backgroundColor: '#fff',
    marginBottom: 15,
  },
});
