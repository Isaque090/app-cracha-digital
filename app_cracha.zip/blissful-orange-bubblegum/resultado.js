import React, { useState } from 'react';
import {
  View,
  Text,
  Button,
  Image,
  StyleSheet,
  Alert,
  TextInput,TouchableOpacity
} from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
export default function Resultado({ route, navigation }) {

  const { nome, curso, rm,imagem,dtnascimento } = route.params;
 
 

 return (
    <View style={styles.container}>
      <View style={styles.card}>
      
     <Text style={styles.titulo}>Cracha do aluno</Text>
 <Image source={{ uri: imagem }} style={styles.imagem} />
  <Text style={styles.label}>Nome</Text>
 <View style={styles.input}>
     <Text style={styles.texto}>{nome}</Text>
      </View>
       <Text style={styles.label}>RM</Text>
 <View style={styles.inputqr}>
     <Text style={styles.texto}>{rm}</Text>
   <TouchableOpacity
  style={styles.botaoQR}
  onPress={() => navigation.navigate('Qrcode', {
    rm: rm
  })}
>
  <MaterialCommunityIcons
    name="qrcode"
    size={28}
    color="#fff"
  />

</TouchableOpacity>
      </View>
       <Text style={styles.label}>Data De Nascimento</Text>
 <View style={styles.input}>
     <Text style={styles.texto}>{dtnascimento}</Text>
      </View>
       <Text style={styles.label}>Curso</Text>
 <View style={styles.input}>
     <Text style={styles.texto}>{curso}</Text>
      </View>

      
       
    </View>
     <TouchableOpacity style={styles.btnVoltar} onPress={()=>navigation.goBack()} >
     <Text y style={styles.txtbtn}>Voltar</Text>
     </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop:70,
    alignItems: 'center',
 
    backgroundColor:'#000'
  },btnVoltar:{
    marginTop:30,
    padding:8,
    borderRadius:10,
    width:100,
backgroundColor:'#fff'
  },
  txtbtn:{
    
marginRight:'auto',
marginLeft:'auto',
    fontSize:20,
  },
  card:{
backgroundColor:'#1d1d1d',
width:400,
height:600,
 borderWidth: 1,
  borderColor: '#007bff',
  borderRadius: 12,
  
  },
  label:{

marginLeft:20,
  color: '#014bff',
    fontSize: 15,
    fontWeight: 'bold',
    letterSpacing: 1,
    marginBottom: 4,
  },

  
  titulo: {
    fontSize: 30,
    fontWeight: 'bold',
    color:'#fff',
    marginRight:'auto',
    marginLeft:'auto',
    marginTop:10,
   
  borderColor: '#00ff88',
  borderRadius: 12,
  borderBottomWidth:6,
   
  },
   
inputqr: {
  marginTop: 4,
  borderBottomWidth: 2,
  borderBottomColor: '#292d35',
  marginLeft: 20,
  marginRight: 20,
  marginBottom: 25,
  flexDirection: 'row',
  flex: 1,
  justifyContent: 'space-between'
},
  input: {
   

   marginTop:4,
   borderBottomWidth: 2,
  borderBottomColor: '#292d35',

  marginLeft:20,
  marginRight:20,

  marginBottom:25,

   },
   texto:{
 fontSize: 25,
  fontWeight: 'bold',
  marginLeft:10,
  paddingLeft:10,
    color:'#fff',
   },

  imagem: {
    width: 150,
    height: 150,
     borderWidth: 2,
  borderColor: '#007bff',
  borderRadius: 80,
  marginLeft:'auto',
  marginRight:'auto',
   marginTop:10,
  
  },

  
});
